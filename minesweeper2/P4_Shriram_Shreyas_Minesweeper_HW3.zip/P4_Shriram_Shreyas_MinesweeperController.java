import java.util.ArrayList;
import java.util.Scanner;

public class P4_Shriram_Shreyas_MinesweeperController {
    private int row;
    private int col;
    private int numMines;
    P4_Shriram_Shreyas_MinesweeperModel model;
    public P4_Shriram_Shreyas_MinesweeperController(int row, int col, int numMines) {
        this.row = row;
        this.col = col;
        this.numMines = numMines;
        ArrayList<ArrayList<P4_Shriram_Shreyas_Tiles>> temp = new ArrayList<ArrayList<P4_Shriram_Shreyas_Tiles>>();
        for(int i = 0; i < col; i++){
            temp.add(new ArrayList<P4_Shriram_Shreyas_Tiles>());
            for(int j = 0; j < row; j++){
                temp.get(i).add(new P4_Shriram_Shreyas_Tiles());
            }
        }

        for(int i = 0; i < numMines; i++){
            int xPos = (int)(Math.random() * col);
            int yPos = (int)(Math.random() * row);
            temp.get(yPos).get(xPos).makeBomb();

        }
        System.out.println();
        model = new P4_Shriram_Shreyas_MinesweeperModel(temp);
    }

    public void printBoard(){
        System.out.print("   ");
        for(int i = 0; i < row; i++){
            if(i < 9)
                System.out.print((i + 1)  + " ");
            else
                System.out.print(((i + 1) % 10)  + " ");
        }
        System.out.println();
        for(int i = 0; i < row; i++){
            if(i < 9)
                System.out.print(" " + (i + 1) + " ");
            else
                System.out.print(" " + ((i + 1) % 10)  + " ");

            for (int j = 0; j < col; j++) {
                System.out.print(model.printTile(i, j) + " ");
            }
            System.out.println();
        }

    }
    public void printBoardDebug(){
        System.out.print("   ");
        for(int i = 0; i < row; i++){
            if(i < 9)
                System.out.print((i + 1)  + " ");
            else
                System.out.print((i % 10 - 1)  + " ");
        }
        System.out.println();
        for(int i = 0; i < row; i++){
            if(i < 9)
                System.out.print(" " + (i + 1) + " ");
            else
                System.out.print(" " + (i - 9) + " ");

            for (int j = 0; j < col; j++) {
                System.out.print(model.printTileDebug(i, j) + " ");
            }
            System.out.println();
        }

    }

    public void run(){
        Scanner scan = new Scanner(System.in);
        printBoard();
        boolean run = true;
        while(run) {
            System.out.println("reveal or flag");
            String ans = scan.next();
            System.out.println("what row");
            int rowNum = scan.nextInt() - 1;
            System.out.println("what col");
            int colNum = scan.nextInt() - 1;
            if(ans.equals("f")){
                model.setFlag(rowNum, colNum);
            }else{
                if(model.getValueAt(rowNum, colNum).getState() % 2 == 0){

                    System.out.println("you are loser");
                    run = false;
                }else if(!(model.isRevealed(rowNum, colNum)))
                    model.recursiveReveal(rowNum, colNum);
            }


            if(run && model.win()){
                System.out.println("victory");
                run = false;
            }
            printBoard();
        }

    }
}
